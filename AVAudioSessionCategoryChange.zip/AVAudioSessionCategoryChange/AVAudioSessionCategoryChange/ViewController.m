//
//  ViewController.m
//  AVAudioSessionCategoryChange
//
//  Created by Naver on 2018. 4. 5..
//  Copyright © 2018년 Naver. All rights reserved.
//

#import <AVFoundation/AVFoundation.h>
#import "ViewController.h"

@interface ViewController ()

@property (nonatomic) BOOL isBtnSeleced;
@property (nonatomic, strong) AVAudioPlayer *audioPlayer;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    // 바로 아래 라인에서 category 변경
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryAmbient error:nil];
    [[AVAudioSession sharedInstance] setActive:YES error:nil];
    
    NSString *soundFilePath = [[NSBundle mainBundle] pathForResource:@"Soothing_Music2_Long" ofType: @"mp3"];
    NSURL *fileURL = [[NSURL alloc] initFileURLWithPath:soundFilePath ];
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:fileURL error:nil];
    self.audioPlayer.numberOfLoops = -1;
    
    UIButton *redBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 100, 50)];
    [redBtn setBackgroundColor:[UIColor redColor]];
    [self.view addSubview:redBtn];
    [redBtn addTarget:self action:@selector(redBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    redBtn.center = CGPointMake(self.view.frame.size.width/2, self.view.frame.size.height/2);
    self.isBtnSeleced = NO;
}

- (void)redBtnAction:(UIButton *)sender{
    if (self.isBtnSeleced == NO) {
        self.isBtnSeleced = YES;
        //start a background sound
        
        [self.audioPlayer play];
        
    } else {
        self.isBtnSeleced = NO;
        [self.audioPlayer stop];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
