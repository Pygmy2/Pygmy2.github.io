//
//  main.m
//  AVAudioSessionCategoryChange
//
//  Created by Naver on 2018. 4. 5..
//  Copyright © 2018년 Naver. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
